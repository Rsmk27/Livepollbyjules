const firebaseConfig = {
    apiKey: "AIzaSyDGGZ-OoqFbXX4YW6TCDnW5X_QU6Ako16U",
    authDomain: "livepoll-686f2.firebaseapp.com",
    projectId: "livepoll-686f2",
    storageBucket: "livepoll-686f2.appspot.com",
    messagingSenderId: "675091634114",
    appId: "1:675091634114:web:dab7028086354d90b9a85b",
    measurementId: "G-ZCX0S2ETKH",
    databaseURL: "https://livepoll-686f2-default-rtdb.firebaseio.com"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const database = firebase.database();
